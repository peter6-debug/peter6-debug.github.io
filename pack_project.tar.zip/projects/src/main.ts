import './style.css';
import { initUI } from './ui';

// 初始化游戏
document.addEventListener('DOMContentLoaded', () => {
  initUI();
});
