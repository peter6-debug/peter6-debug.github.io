// 游戏类型定义

export type CardSuit = '♥' | '♦' | '♣' | '♠';
export type CardColor = 'red' | 'black';

export interface Card {
  id: string;
  name: string;
  type: CardType;
  suit: CardSuit;
  point: number;
  color: CardColor;
  description: string;
}

export type CardType = 'basic' | 'trick' | 'equip';

export type EquipType = 'weapon' | 'armor' | 'horse' | 'treasure';

export interface EquipCard extends Card {
  equipType: EquipType;
}

export interface General {
  id: string;
  name: string;
  title: string;
  hp: number;
  skills: Skill[];
  gender: 'male' | 'female';
}

export interface Skill {
  name: string;
  description: string;
  canActivate: (game: Game, player: Player) => boolean;
  activate: (game: Game, player: Player, params?: any) => void;
}

export interface Player {
  id: string;
  name: string;
  general: General | null;
  hp: number;
  maxHp: number;
  handCards: Card[];
  equipCards: {
    weapon: EquipCard | null;
    armor: EquipCard | null;
    horse: EquipCard | null;
    treasure: EquipCard | null;
  };
  skills: string[];
  status: PlayerStatus;
  isAI: boolean;
  roomId?: string;
}

export interface PlayerStatus {
  alive: boolean;
  dead?: boolean;
  cannotUseJiming?: boolean;
  cannotUseCards?: boolean;
  cannotTargetPlayer?: string;
  canGuangbo?: boolean;
  canLingdao?: boolean;
  justDamaged?: boolean;
  justDied?: boolean;
  justBeTargeted?: boolean;
  justUsedGuangbo?: boolean;
  justUsedTrick?: boolean;
  justLostLastCard?: boolean;
  justRecoveredHp?: boolean;
  justReceivedCard?: boolean;
  canUseJiuquan?: boolean;
  canUseBaoRong?: boolean;
  canUseDaai?: boolean;
  canUseYuxin?: boolean;
  canUseDongcha?: boolean;
  canUseShanting?: boolean;
  pendingJudge?: boolean;
  pendingJiming?: { count: number; target: Player };
  lianhuan?: boolean;
  damagePlus?: number;
  extraDamage?: number;
  extraJimingDamage?: number;
  extraDraw?: number;
  skipNextTurn?: boolean;
  usedTuxi?: boolean;
  usedXianzhi?: boolean;
  usedTiaoxin?: boolean;
  usedZhirun?: boolean;
  usedJianren?: boolean;
  usedLucky?: boolean;
  usedXingnao?: boolean;
  usedGengyun?: boolean;
  usedShengfu?: boolean;
  usedWaiba?: boolean;
  usedMeili?: boolean;
  usedBinggong?: boolean;
  usedMiaobi?: boolean;
  usedJieyou?: boolean;
  firstJimingInTurn?: boolean;
  lastJimingInvalid?: boolean;
}

export interface Room {
  id: string;
  players: Player[];
  deck: Card[];
  discardPile: Card[];
  currentPlayerIndex: number;
  phase: GamePhase;
  turnPlayerIndex: number;
  status: RoomStatus;
}

export type GamePhase = 'prepare' | 'draw' | 'main' | 'play' | 'discard' | 'end';
export type RoomStatus = 'waiting' | 'playing' | 'finished';

export interface Game {
  room: Room;
  selectedCard: Card | null;
  targetPlayer: Player | null;
  actionHistory: Action[];
  log: string[];
}

export interface Action {
  type: string;
  playerId: string;
  targetId?: string;
  cardId?: string;
  data?: any;
  timestamp: number;
}

// 卡牌效果类型
export interface CardEffect {
  (game: Game, source: Player, target: Player, card: Card): void | boolean;
}

// 技能激活条件
export interface SkillCondition {
  (game: Game, player: Player): boolean;
}

// 游戏事件
export type GameEvent = 
  | 'cardUsed'
  | 'damageDealt'
  | 'cardDrawn'
  | 'phaseChanged'
  | 'playerDied'
  | 'skillActivated'
  | 'judgeResult';

export interface GameEventHandler {
  event: GameEvent;
  handler: (game: Game, ...args: any[]) => void;
}

// 游戏模式
export type GameMode = 'practice' | 'online';

// 房间信息
export interface RoomInfo {
  id: string;
  hostId: string;
  players: string[];
  status: RoomStatus;
  maxPlayers: number;
}

// 联机房间
export interface OnlineRoom extends RoomInfo {
  joinCode: string;
  createdAt: number;
}
