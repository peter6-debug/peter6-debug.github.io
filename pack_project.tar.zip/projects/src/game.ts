import { Card, Player, Room, Game, GamePhase, GameMode, CardType, EquipCard } from './types';
import { createDeck, isJiming, isGuangbo, isXiaohonghua, isManfenshijuan, isTrickCard } from './data/cards';
import { getRandomGenerals, getGeneralById } from './data/generals';

// 游戏状态管理
class GameManager {
  private games: Map<string, Game> = new Map();
  private rooms: Map<string, Room> = new Map();
  private players: Map<string, Player> = new Map();
  
  // 创建房间
  createRoom(roomId: string, hostId: string): Room {
    const room: Room = {
      id: roomId,
      players: [],
      deck: createDeck(),
      discardPile: [],
      currentPlayerIndex: 0,
      phase: 'prepare',
      turnPlayerIndex: 0,
      status: 'waiting'
    };
    this.rooms.set(roomId, room);
    return room;
  }
  
  // 获取房间
  getRoom(roomId: string): Room | undefined {
    return this.rooms.get(roomId);
  }
  
  // 加入房间
  joinRoom(roomId: string, player: Player): boolean {
    const room = this.rooms.get(roomId);
    if (!room || room.status !== 'waiting' || room.players.length >= 8) {
      return false;
    }
    
    // 检查武将是否重复
    const usedGeneralIds = room.players.map(p => p.general?.id);
    if (player.general && usedGeneralIds.includes(player.general.id)) {
      return false;
    }
    
    room.players.push(player);
    this.players.set(player.id, player);
    return true;
  }
  
  // 开始游戏
  startGame(roomId: string): Game | null {
    const room = this.rooms.get(roomId);
    if (!room || room.players.length < 2) {
      return null;
    }
    
    // 发初始手牌
    room.players.forEach(player => {
      for (let i = 0; i < 4; i++) {
        if (room.deck.length > 0) {
          player.handCards.push(room.deck.pop()!);
        }
      }
    });
    
    room.status = 'playing';
    room.phase = 'draw';
    room.turnPlayerIndex = 0;
    
    const game: Game = {
      room,
      selectedCard: null,
      targetPlayer: null,
      actionHistory: [],
      log: ['游戏开始！']
    };
    
    this.games.set(roomId, game);
    return game;
  }
  
  // 获取游戏
  getGame(roomId: string): Game | undefined {
    return this.games.get(roomId);
  }
  
  // 摸牌
  drawCards(room: Room, player: Player, count: number): Card[] {
    const drawn: Card[] = [];
    for (let i = 0; i < count; i++) {
      if (room.deck.length === 0) {
        this.reshuffleDeck(room);
      }
      if (room.deck.length > 0) {
        const card = room.deck.pop()!;
        player.handCards.push(card);
        drawn.push(card);
      }
    }
    return drawn;
  }
  
  // 洗牌
  private reshuffleDeck(room: Room): void {
    if (room.discardPile.length > 0) {
      room.deck = [...room.discardPile].sort(() => Math.random() - 0.5);
      room.discardPile = [];
    }
  }
  
  // 弃牌
  discardCard(room: Room, player: Player, card: Card): void {
    const index = player.handCards.findIndex(c => c.id === card.id);
    if (index !== -1) {
      player.handCards.splice(index, 1);
      room.discardPile.push(card);
    }
  }
  
  // 使用卡牌
  useCard(game: Game, player: Player, card: Card, targets: Player[]): boolean {
    const room = game.room;
    
    // 检查是否是基本牌
    if (card.type === 'basic') {
      return this.useBasicCard(game, player, card, targets);
    }
    
    // 检查是否是锦囊牌
    if (card.type === 'trick') {
      return this.useTrickCard(game, player, card, targets);
    }
    
    // 检查是否是装备牌
    if (card.type === 'equip') {
      return this.useEquipCard(player, card as EquipCard, targets[0]);
    }
    
    return false;
  }
  
  // 使用基本牌
  private useBasicCard(game: Game, player: Player, card: Card, targets: Player[]): boolean {
    const room = game.room;
    
    // 记名
    if (isJiming(card)) {
      if (targets.length === 0) return false;
      const target = targets[0];
      
      // 检查距离
      const distance = this.getDistance(room, player, target);
      if (distance > 1) return false;
      
      // 检查是否有闪
      const damage = card.name === '记名' ? 1 : (card.name === '严重记名' ? 2 : 2);
      this.damage(game, player, target, damage);
      
      game.log.push(`${player.name} 使用了【${card.name}】，对 ${target.name} 造成了 ${damage} 点伤害`);
    }
    
    // 广播（闪）
    else if (isGuangbo(card)) {
      player.status.canGuangbo = true;
      game.log.push(`${player.name} 使用了【${card.name}】`);
    }
    
    // 小红花（桃）
    else if (isXiaohonghua(card)) {
      if (player.hp < player.maxHp) {
        player.hp = Math.min(player.hp + 1, player.maxHp);
        game.log.push(`${player.name} 使用了【${card.name}】，恢复了1点体力`);
      } else if (targets.length > 0) {
        const target = targets[0];
        if (target.hp <= 0) {
          target.hp = Math.min(target.hp + 1, target.maxHp);
          game.log.push(`${player.name} 使用了【${card.name}】，营救了 ${target.name}`);
        }
      }
    }
    
    // 满分试卷（无中生有）
    else if (isManfenshijuan(card)) {
      this.drawCards(room, player, 2);
      game.log.push(`${player.name} 使用了【${card.name}】，摸了两张牌`);
    }
    
    // 移除手牌
    this.discardCard(room, player, card);
    return true;
  }
  
  // 使用锦囊牌
  private useTrickCard(game: Game, player: Player, card: Card, targets: Player[]): boolean {
    const room = game.room;
    
    switch (card.name) {
      // 班干部指令
      case '班干部指令':
        if (targets.length > 0) {
          targets[0].status.cannotUseJiming = true;
          game.log.push(`${player.name} 对 ${targets[0].name} 使用了【班干部指令】`);
        }
        break;
        
      // 调开老师
      case '调开老师':
        room.players.forEach(p => {
          if (p.id !== player.id) {
            p.status.cannotTargetPlayer = player.id;
          }
        });
        game.log.push(`${player.name} 使用了【调开老师】`);
        break;
        
      // 没收小玩具
      case '没收小玩具':
        if (targets.length > 0 && targets[0].handCards.length > 0) {
          const idx = Math.floor(Math.random() * targets[0].handCards.length);
          const removed = targets[0].handCards.splice(idx, 1)[0];
          room.discardPile.push(removed);
          game.log.push(`${player.name} 没收了 ${targets[0].name} 的1张牌`);
        }
        break;
        
      // 点燃小纸条
      case '点燃小纸条':
        if (targets.length > 0 && targets[0].handCards.length > 0) {
          const idx = Math.floor(Math.random() * targets[0].handCards.length);
          const shown = targets[0].handCards[idx];
          if (shown.color === 'red') {
            this.damage(game, player, targets[0], 1);
            game.log.push(`${player.name} 对 ${targets[0].name} 使用了【点燃小纸条】，造成1点伤害`);
          } else {
            game.log.push(`${player.name} 对 ${targets[0].name} 使用了【点燃小纸条】，但没有造成伤害`);
          }
        }
        break;
        
      // 借东西不还
      case '借东西不还':
        if (targets.length > 0) {
          const distance = this.getDistance(room, player, targets[0]);
          if (distance <= 1 && targets[0].handCards.length > 0) {
            const idx = Math.floor(Math.random() * targets[0].handCards.length);
            const stolen = targets[0].handCards.splice(idx, 1)[0];
            player.handCards.push(stolen);
            game.log.push(`${player.name} 从 ${targets[0].name} 借走了1张牌`);
          }
        }
        break;
        
      // 意外奖励
      case '意外奖励':
        this.drawCards(room, player, 2);
        game.log.push(`${player.name} 使用了【意外奖励】`);
        break;
        
      // 小组分享会
      case '小组分享会':
        room.players.forEach(p => {
          if (p.hp < p.maxHp) {
            p.hp = Math.min(p.hp + 1, p.maxHp);
          }
          this.drawCards(room, p, 1);
        });
        game.log.push(`${player.name} 使用了【小组分享会】`);
        break;
        
      // 全班分享小红花
      case '全班分享小红花':
        room.players.forEach(p => {
          p.hp = Math.min(p.hp + 1, p.maxHp);
        });
        game.log.push(`${player.name} 使用了【全班分享小红花】`);
        break;
        
      // 连环扣
      case '连环扣':
        if (targets.length >= 2) {
          targets.forEach(t => {
            t.status.lianhuan = true;
          });
          game.log.push(`${player.name} 将 ${targets.map(t => t.name).join('、')} 连环了`);
        }
        break;
        
      // 发作业本
      case '发作业本':
        const count = Math.min(room.players.length, room.deck.length);
        const picked: Card[] = [];
        for (let i = 0; i < count; i++) {
          if (room.deck.length > 0) {
            picked.push(room.deck.pop()!);
          }
        }
        // 依次选择
        let currentIdx = room.players.indexOf(player);
        picked.forEach(card => {
          // 这里简化为直接发给玩家
          room.players[currentIdx % room.players.length].handCards.push(card);
          currentIdx++;
        });
        game.log.push(`${player.name} 使用了【发作业本】`);
        break;
        
      // 班主任回班
      case '班主任回班':
        room.players.forEach(p => {
          if (p.id !== player.id) {
            const hasJiming = p.handCards.some(c => isJiming(c));
            if (!hasJiming) {
              this.damage(game, player, p, 1);
            }
          }
        });
        game.log.push(`${player.name} 使用了【班主任回班】`);
        break;
        
      // 领导检查
      case '领导检查':
        player.status.canLingdao = true;
        game.log.push(`${player.name} 使用了【领导检查】`);
        break;
        
      default:
        game.log.push(`${player.name} 使用了【${card.name}】`);
    }
    
    this.discardCard(room, player, card);
    return true;
  }
  
  // 使用装备牌
  private useEquipCard(player: Player, card: EquipCard, target: Player): boolean {
    const equip = player.equipCards;
    
    switch (card.equipType) {
      case 'weapon':
        if (equip.weapon) return false;
        equip.weapon = card;
        break;
      case 'armor':
        if (equip.armor) return false;
        equip.armor = card;
        break;
      case 'horse':
        if (equip.horse) return false;
        equip.horse = card;
        break;
      case 'treasure':
        if (equip.treasure) return false;
        equip.treasure = card;
        break;
    }
    
    const idx = player.handCards.findIndex(c => c.id === card.id);
    if (idx !== -1) {
      player.handCards.splice(idx, 1);
    }
    
    return true;
  }
  
  // 造成伤害
  damage(game: Game, source: Player, target: Player, amount: number): void {
    // 检查防具
    if (target.equipCards.armor) {
      const armor = target.equipCards.armor;
      // 纪律盾牌
      if (armor.name === '纪律盾牌' && source.handCards.some(c => c.color === 'black')) {
        game.log.push(`${target.name} 的【纪律盾牌】免疫了黑色记名`);
        return;
      }
      // 手工纸铠甲
      if (armor.name === '手工纸铠甲') {
        amount += 1;
      }
    }
    
    target.hp -= amount;
    target.status.justDamaged = true;
    
    if (target.hp <= 0) {
      target.status.justDied = true;
      game.log.push(`${target.name} 进入了濒死状态`);
    }
  }
  
  // 计算距离
  getDistance(room: Room, from: Player, to: Player): number {
    let distance = 1;
    
    // 武器距离
    if (from.equipCards.weapon) {
      distance = 0;
    }
    
    // 马的距离修正
    if (from.equipCards.horse) {
      distance += 1;
    }
    if (to.equipCards.horse) {
      distance += 1;
    }
    
    // 技能距离修正
    if (from.general?.skills.some(s => s.name === '辽阔' || s.name === '出众')) {
      distance -= 1;
    }
    if (to.general?.skills.some(s => s.name === '子涵')) {
      distance += 1;
    }
    
    return Math.max(1, distance);
  }
  
  // 回合结束
  endTurn(game: Game): void {
    const room = game.room;
    const player = room.players[room.turnPlayerIndex];
    
    // 清除回合状态
    player.status.cannotUseJiming = false;
    player.status.cannotTargetPlayer = undefined;
    
    // 下一个玩家
    room.turnPlayerIndex = (room.turnPlayerIndex + 1) % room.players.length;
    room.phase = 'draw';
    
    // 检查死亡
    room.players.forEach(p => {
      if (p.hp <= 0 && p.status.alive) {
        p.status.dead = true;
        p.status.alive = false;
        game.log.push(`${p.name} 阵亡`);
      }
    });
    
    // 检查胜利条件
    const alivePlayers = room.players.filter(p => p.status.alive);
    if (alivePlayers.length <= 1) {
      room.status = 'finished';
      if (alivePlayers.length === 1) {
        game.log.push(`${alivePlayers[0].name} 获胜！`);
      }
    }
  }
  
  // 创建玩家
  createPlayer(id: string, name: string, isAI: boolean = false): Player {
    return {
      id,
      name,
      general: null,
      hp: 0,
      maxHp: 0,
      handCards: [],
      equipCards: {
        weapon: null,
        armor: null,
        horse: null,
        treasure: null
      },
      skills: [],
      status: {
        alive: false,
        cannotUseJiming: false,
        cannotTargetPlayer: undefined,
        canGuangbo: false,
        canLingdao: false,
        justDamaged: false,
        justDied: false,
        lianhuan: false,
        usedTuxi: false,
        usedXianzhi: false,
        usedTiaoxin: false,
        usedZhirun: false,
        usedJianren: false
      },
      isAI
    };
  }
  
  // 选择武将
  selectGeneral(room: Room, playerId: string, generalId: string): boolean {
    const player = room.players.find(p => p.id === playerId);
    if (!player) return false;
    
    const general = getGeneralById(generalId);
    if (!general) return false;
    
    // 检查是否已被选择
    const usedIds = room.players.filter(p => p.general).map(p => p.general!.id);
    if (usedIds.includes(generalId)) return false;
    
    player.general = general;
    player.maxHp = general.hp;
    player.hp = general.hp;
    player.status.alive = true;
    
    return true;
  }
  
  // 获取可用的武将
  getAvailableGenerals(room: Room): any[] {
    const usedIds = room.players.filter(p => p.general).map(p => p.general!.id);
    return getRandomGenerals(5).filter(g => !usedIds.includes(g.id));
  }
  
  // AI 行动
  aiAction(game: Game): void {
    const room = game.room;
    const player = room.players[room.turnPlayerIndex];
    
    if (!player.isAI) return;
    
    // 简单 AI：优先使用杀，然后使用锦囊，最后摸牌
    // 这里只是一个简单的示例
    setTimeout(() => {
      // 摸牌阶段
      this.drawCards(room, player, 2);
      
      // 出牌阶段
      const jiming = player.handCards.find(c => isJiming(c));
      if (jiming) {
        const targets = room.players.filter(p => 
          p.id !== player.id && 
          p.status.alive && 
          this.getDistance(room, player, p) <= 1
        );
        if (targets.length > 0) {
          this.useBasicCard(game, player, jiming, [targets[0]]);
        }
      }
      
      // 结束回合
      this.endTurn(game);
    }, 1000);
  }
}

export const gameManager = new GameManager();

// 导出游戏状态
export function createGameState(roomId: string): Game | null {
  return gameManager.startGame(roomId);
}

export function getGame(roomId: string): Game | undefined {
  return gameManager.getGame(roomId);
}

export function getRoom(roomId: string): Room | undefined {
  return gameManager.getRoom(roomId);
}

export function joinRoom(roomId: string, player: Player): boolean {
  return gameManager.joinRoom(roomId, player);
}

export function createRoom(roomId: string, hostId: string): Room {
  return gameManager.createRoom(roomId, hostId);
}

export function createPlayer(id: string, name: string, isAI: boolean = false): Player {
  return gameManager.createPlayer(id, name, isAI);
}

export function selectGeneral(roomId: string, playerId: string, generalId: string): boolean {
  const room = gameManager.getRoom(roomId);
  if (!room) return false;
  return gameManager.selectGeneral(room, playerId, generalId);
}

export function getAvailableGenerals(roomId: string): any[] {
  const room = gameManager.getRoom(roomId);
  if (!room) return [];
  return gameManager.getAvailableGenerals(room);
}
