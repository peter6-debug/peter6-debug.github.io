import './index.css';
import { initApp } from './main';

// Initialize the application
initApp();
