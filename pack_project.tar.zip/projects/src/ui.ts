import { Card, Player, Room, Game } from './types';
import { isJiming, isGuangbo, isXiaohonghua, isManfenshijuan, isTrickCard, isBasicCard } from './data/cards';
import { getAvailableGenerals, getRoom, joinRoom, createRoom, createPlayer, selectGeneral, createGameState, getGame } from './game';

// 当前游戏状态
let currentRoomId: string = '';
let currentPlayerId: string = '';
let currentGame: Game | null = null;
let currentRoom: Room | null = null;

// DOM 元素
const app = document.getElementById('app')!;

// 初始化
export function initUI(): void {
  showMainMenu();
}

// 显示主菜单
function showMainMenu(): void {
  app.innerHTML = `
    <div class="main-menu">
      <h1>诈尸杀</h1>
      <div class="menu-buttons">
        <button id="btn-practice" class="menu-btn">个人练习模式</button>
        <button id="btn-create-room" class="menu-btn">创建房间</button>
        <button id="btn-join-room" class="menu-btn">加入房间</button>
      </div>
    </div>
  `;
  
  document.getElementById('btn-practice')?.addEventListener('click', startPracticeMode);
  document.getElementById('btn-create-room')?.addEventListener('click', showCreateRoom);
  document.getElementById('btn-join-room')?.addEventListener('click', showJoinRoom);
}

// 显示创建房间
function showCreateRoom(): void {
  app.innerHTML = `
    <div class="create-room">
      <h2>创建房间</h2>
      <div class="form-group">
        <label>房间号：</label>
        <input type="text" id="room-id" value="${generateRoomId()}" readonly>
      </div>
      <div class="form-group">
        <label>你的名字：</label>
        <input type="text" id="player-name" placeholder="请输入名字">
      </div>
      <button id="btn-confirm-create" class="menu-btn">创建</button>
      <button id="btn-back" class="menu-btn btn-secondary">返回</button>
    </div>
  `;
  
  document.getElementById('btn-confirm-create')?.addEventListener('click', createNewRoom);
  document.getElementById('btn-back')?.addEventListener('click', showMainMenu);
}

// 生成房间号
function generateRoomId(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// 创建新房间
function createNewRoom(): void {
  const roomId = (document.getElementById('room-id') as HTMLInputElement).value;
  const playerName = (document.getElementById('player-name') as HTMLInputElement).value || '玩家1';
  
  if (!roomId) {
    alert('请输入房间号');
    return;
  }
  
  currentRoomId = roomId;
  currentPlayerId = 'player_' + Date.now();
  
  const room = createRoom(roomId, currentPlayerId);
  const player = createPlayer(currentPlayerId, playerName);
  
  joinRoom(roomId, player);
  
  showWaitingRoom(room);
}

// 显示加入房间
function showJoinRoom(): void {
  app.innerHTML = `
    <div class="join-room">
      <h2>加入房间</h2>
      <div class="form-group">
        <label>房间号：</label>
        <input type="text" id="join-room-id" placeholder="请输入房间号">
      </div>
      <div class="form-group">
        <label>你的名字：</label>
        <input type="text" id="player-name" placeholder="请输入名字">
      </div>
      <button id="btn-confirm-join" class="menu-btn">加入</button>
      <button id="btn-back" class="menu-btn btn-secondary">返回</button>
    </div>
  `;
  
  document.getElementById('btn-confirm-join')?.addEventListener('click', joinExistingRoom);
  document.getElementById('btn-back')?.addEventListener('click', showMainMenu);
}

// 加入现有房间
function joinExistingRoom(): void {
  const roomId = (document.getElementById('join-room-id') as HTMLInputElement).value;
  const playerName = (document.getElementById('player-name') as HTMLInputElement).value || '玩家';
  
  if (!roomId) {
    alert('请输入房间号');
    return;
  }
  
  const room = getRoom(roomId);
  if (!room) {
    alert('房间不存在');
    return;
  }
  
  currentRoomId = roomId;
  currentPlayerId = 'player_' + Date.now();
  
  const player = createPlayer(currentPlayerId, playerName);
  
  const success = joinRoom(roomId, player);
  if (!success) {
    alert('加入失败');
    return;
  }
  
  showWaitingRoom(room);
}

// 显示等待房间
function showWaitingRoom(room: Room): void {
  currentRoom = room;
  
  const playersHtml = room.players.map(p => `
    <div class="player-item">
      <span>${p.name}</span>
      <span>${p.general ? p.general.name : '未选择武将'}</span>
    </div>
  `).join('');
  
  app.innerHTML = `
    <div class="waiting-room">
      <h2>房间: ${room.id}</h2>
      <div class="players-list">
        ${playersHtml}
      </div>
      <div class="room-info">
        <p>等待玩家加入...</p>
        <p>房间号: <strong>${room.id}</strong></p>
      </div>
      ${room.players.find(p => p.id === currentPlayerId) ? `
        <button id="btn-select-general" class="menu-btn">选择武将</button>
      ` : ''}
      ${room.players.length >= 2 && room.players.every(p => p.general) ? `
        <button id="btn-start-game" class="menu-btn">开始游戏</button>
      ` : ''}
    </div>
  `;
  
  document.getElementById('btn-select-general')?.addEventListener('click', () => showSelectGeneral(room));
  
  document.getElementById('btn-start-game')?.addEventListener('click', () => {
    const game = createGameState(currentRoomId);
    if (game) {
      currentGame = game;
      startGame(game);
    }
  });
  
  // 刷新等待房间
  setTimeout(() => {
    const updatedRoom = getRoom(currentRoomId);
    if (updatedRoom) {
      showWaitingRoom(updatedRoom);
    }
  }, 2000);
}

// 显示选择武将
function showSelectGeneral(room: Room): void {
  const generals = getAvailableGenerals(currentRoomId);
  const player = room.players.find(p => p.id === currentPlayerId);
  
  if (!player || player.general) {
    alert('你已选择武将');
    return;
  }
  
  const generalsHtml = generals.map(g => `
    <div class="general-card" data-id="${g.id}">
      <div class="general-avatar">${g.name[0]}</div>
      <div class="general-name">${g.name}</div>
      <div class="general-title">${g.title}</div>
      <div class="general-hp">体力: ${g.hp}</div>
    </div>
  `).join('');
  
  app.innerHTML = `
    <div class="select-general">
      <h2>选择武将</h2>
      <p>从以下5个武将中选择一个</p>
      <div class="generals-grid">
        ${generalsHtml}
      </div>
      <button id="btn-back" class="menu-btn btn-secondary">返回</button>
    </div>
  `;
  
  document.querySelectorAll('.general-card').forEach(card => {
    card.addEventListener('click', () => {
      const generalId = card.getAttribute('data-id')!;
      selectGeneral(currentRoomId, currentPlayerId, generalId);
      
      const updatedRoom = getRoom(currentRoomId);
      if (updatedRoom) {
        showWaitingRoom(updatedRoom);
      }
    });
  });
  
  document.getElementById('btn-back')?.addEventListener('click', () => {
    const room = getRoom(currentRoomId);
    if (room) showWaitingRoom(room);
  });
}

// 开始练习模式
function startPracticeMode(): void {
  currentRoomId = 'practice_' + Date.now();
  currentPlayerId = 'player_' + Date.now();
  
  const room = createRoom(currentRoomId, currentPlayerId);
  const player = createPlayer(currentPlayerId, '你', false);
  const ai1 = createPlayer('ai_1', '电脑1', true);
  const ai2 = createPlayer('ai_2', '电脑2', true);
  
  joinRoom(currentRoomId, player);
  joinRoom(currentRoomId, ai1);
  joinRoom(currentRoomId, ai2);
  
  // 自动选择武将
  const generals = getAvailableGenerals(currentRoomId);
  room.players.forEach((p, idx) => {
    if (generals[idx]) {
      selectGeneral(currentRoomId, p.id, generals[idx].id);
    }
  });
  
  const game = createGameState(currentRoomId);
  if (game) {
    currentGame = game;
    startGame(game);
  }
}

// 开始游戏
function startGame(game: Game): void {
  renderGameBoard(game);
  
  // 游戏循环
  gameLoop(game);
}

// 游戏循环
function gameLoop(game: Game): void {
  if (game.room.status === 'finished') {
    alert('游戏结束！');
    showMainMenu();
    return;
  }
  
  const player = game.room.players[game.room.turnPlayerIndex];
  
  if (player.isAI) {
    // AI 行动
    setTimeout(() => {
      aiAction(game);
      renderGameBoard(game);
      gameLoop(game);
    }, 1500);
  } else {
    // 玩家回合
    renderGameBoard(game);
  }
}

// AI 行动
function aiAction(game: Game): void {
  const room = game.room;
  const player = room.players[room.turnPlayerIndex];
  
  // 摸牌
  for (let i = 0; i < 2; i++) {
    if (room.deck.length > 0) {
      player.handCards.push(room.deck.pop()!);
    }
  }
  
  // 使用杀
  const jiming = player.handCards.find(c => isJiming(c));
  if (jiming) {
    const targets = room.players.filter(p => 
      p.id !== player.id && p.status.alive && getDistance(player, p) <= 1
    );
    if (targets.length > 0) {
      useCard(game, player, jiming, [targets[0]]);
    }
  }
  
  // 结束回合
  endTurn(game);
}

// 渲染游戏面板
function renderGameBoard(game: Game): void {
  const room = game.room;
  const currentPlayer = room.players[room.turnPlayerIndex];
  const myPlayer = room.players.find(p => p.id === currentPlayerId);
  
  let playersHtml = '';
  room.players.forEach((p, idx) => {
    const isCurrent = idx === room.turnPlayerIndex;
    const isMe = p.id === currentPlayerId;
    const status = p.status.alive ? 'alive' : 'dead';
    
    const equipCards = Object.values(p.equipCards).filter(Boolean);
    
    playersHtml += `
      <div class="player-area ${status} ${isCurrent ? 'current-turn' : ''}" data-player-id="${p.id}">
        <div class="player-info">
          <div class="player-avatar">${p.general?.name[0] || '?'}</div>
          <div class="player-details">
            <div class="player-name">${p.name}</div>
            <div class="player-general">${p.general?.name || '未选择'}</div>
            <div class="player-hp">
              ${renderHp(p.hp, p.maxHp)}
            </div>
          </div>
        </div>
        <div class="player-hand-count">手牌: ${p.handCards.length}</div>
        <div class="player-equips">
          ${equipCards.map(e => `<span class="equip-icon">${e!.name[0]}</span>`).join('')}
        </div>
      </div>
    `;
  });
  
  const logHtml = game.log.slice(-5).map(l => `<div class="log-item">${l}</div>`).join('');
  
  let handCardsHtml = '';
  if (myPlayer) {
    handCardsHtml = myPlayer.handCards.map(card => `
      <div class="hand-card" data-card-id="${card.id}">
        <div class="card-suit ${card.color}">${card.suit}</div>
        <div class="card-name">${card.name}</div>
        <div class="card-point">${card.point}</div>
      </div>
    `).join('');
  }
  
  app.innerHTML = `
    <div class="game-board">
      <div class="game-top">
        <div class="deck-info">
          牌堆: ${room.deck.length} | 弃牌: ${room.discardPile.length}
        </div>
        <div class="game-log">
          ${logHtml}
        </div>
      </div>
      
      <div class="players-container">
        ${playersHtml}
      </div>
      
      <div class="game-controls">
        ${currentPlayer && !currentPlayer.isAI && currentPlayer.id === currentPlayerId ? `
          <button id="btn-end-turn" class="control-btn">结束回合</button>
        ` : ''}
        ${currentPlayer?.isAI ? `
          <div class="ai-thinking">电脑思考中...</div>
        ` : ''}
      </div>
      
      <div class="hand-cards-container">
        <h3>你的手牌</h3>
        <div class="hand-cards">
          ${handCardsHtml}
        </div>
      </div>
    </div>
  `;
  
  // 绑定事件
  document.querySelectorAll('.hand-card').forEach(cardEl => {
    cardEl.addEventListener('click', () => {
      const cardId = cardEl.getAttribute('data-card-id')!;
      const card = myPlayer?.handCards.find(c => c.id === cardId);
      if (card) {
        handleCardClick(game, card);
      }
    });
  });
  
  document.querySelectorAll('.player-area').forEach(playerEl => {
    playerEl.addEventListener('click', () => {
      const playerId = playerEl.getAttribute('data-player-id')!;
      const target = room.players.find(p => p.id === playerId);
      if (target && game.selectedCard) {
        handleTargetSelect(game, target);
      }
    });
  });
  
  document.getElementById('btn-end-turn')?.addEventListener('click', () => {
    endTurn(game);
    gameLoop(game);
  });
}

// 渲染体力
function renderHp(hp: number, maxHp: number): string {
  let html = '';
  for (let i = 0; i < maxHp; i++) {
    if (i < hp) {
      html += '<span class="hp-dot hp-full"></span>';
    } else {
      html += '<span class="hp-dot hp-empty"></span>';
    }
  }
  return html;
}

// 处理卡牌点击
function handleCardClick(game: Game, card: Card): void {
  const room = game.room;
  const player = room.players.find(p => p.id === currentPlayerId);
  
  if (!player) return;
  
  // 检查是否可以打出手牌
  if (player.status.cannotUseJiming && isJiming(card)) {
    alert('本回合不能使用记名');
    return;
  }
  
  // 检查目标
  const needsTarget = isJiming(card) || isTrickCard(card);
  
  if (needsTarget) {
    // 选择目标
    game.selectedCard = card;
    alert(`请选择要使用【${card.name}】的目标`);
    renderGameBoard(game);
  } else {
    // 直接使用
    useCard(game, player, card, []);
    renderGameBoard(game);
  }
}

// 处理目标选择
function handleTargetSelect(game: Game, target: Player): void {
  const room = game.room;
  const player = room.players.find(p => p.id === currentPlayerId);
  
  if (!player || !game.selectedCard) return;
  
  // 检查距离
  if (isJiming(game.selectedCard)) {
    const distance = getDistance(player, target);
    if (distance > 1) {
      alert('距离太远');
      return;
    }
  }
  
  useCard(game, player, game.selectedCard, [target]);
  game.selectedCard = null;
  renderGameBoard(game);
}

// 使用卡牌
function useCard(game: Game, player: Player, card: Card, targets: Player[]): void {
  const room = game.room;
  
  // 从手牌中移除
  const idx = player.handCards.findIndex(c => c.id === card.id);
  if (idx !== -1) {
    player.handCards.splice(idx, 1);
  }
  
  if (isJiming(card)) {
    // 记名
    if (targets.length > 0) {
      const target = targets[0];
      let damage = 1;
      
      if (card.name === '严重记名') damage = 2;
      if (card.name === '警告记名') damage = 2;
      
      // 检查防具
      if (target.equipCards.armor) {
        const armor = target.equipCards.armor;
        if (armor.name === '纪律盾牌' && card.color === 'black') {
          game.log.push(`${target.name} 的【纪律盾牌】免疫了黑色记名`);
          return;
        }
        if (armor.name === '手工纸铠甲' && card.name === '警告记名') {
          damage += 1;
        }
      }
      
      target.hp -= damage;
      game.log.push(`${player.name} 使用【${card.name}】对 ${target.name} 造成 ${damage} 点伤害`);
      
      if (target.hp <= 0) {
        target.status.alive = false;
        game.log.push(`${target.name} 阵亡`);
      }
    }
  } else if (isGuangbo(card)) {
    game.log.push(`${player.name} 使用了【广播做好事记录】`);
  } else if (isXiaohonghua(card)) {
    if (player.hp < player.maxHp) {
      player.hp = Math.min(player.hp + 1, player.maxHp);
      game.log.push(`${player.name} 恢复了1点体力`);
    }
  } else if (isManfenshijuan(card)) {
    for (let i = 0; i < 2; i++) {
      if (room.deck.length > 0) {
        player.handCards.push(room.deck.pop()!);
      }
    }
    game.log.push(`${player.name} 使用了【满分试卷】`);
  } else if (isTrickCard(card)) {
    // 锦囊牌逻辑
    switch (card.name) {
      case '没收小玩具':
        if (targets.length > 0 && targets[0].handCards.length > 0) {
          const removeIdx = Math.floor(Math.random() * targets[0].handCards.length);
          const removed = targets[0].handCards.splice(removeIdx, 1)[0];
          room.discardPile.push(removed);
          game.log.push(`${player.name} 没收了 ${targets[0].name} 的1张牌`);
        }
        break;
      case '借东西不还':
        if (targets.length > 0) {
          const distance = getDistance(player, targets[0]);
          if (distance <= 1 && targets[0].handCards.length > 0) {
            const removeIdx = Math.floor(Math.random() * targets[0].handCards.length);
            const stolen = targets[0].handCards.splice(removeIdx, 1)[0];
            player.handCards.push(stolen);
            game.log.push(`${player.name} 从 ${targets[0].name} 借走了1张牌`);
          }
        }
        break;
      case '意外奖励':
        for (let i = 0; i < 2; i++) {
          if (room.deck.length > 0) {
            player.handCards.push(room.deck.pop()!);
          }
        }
        game.log.push(`${player.name} 使用了【意外奖励】`);
        break;
      default:
        game.log.push(`${player.name} 使用了【${card.name}】`);
    }
  } else if (card.type === 'equip') {
    // 装备牌
    const equip = player.equipCards;
    const equipCard = card as any;
    
    switch (equipCard.equipType) {
      case 'weapon':
        if (!equip.weapon) equip.weapon = equipCard;
        break;
      case 'armor':
        if (!equip.armor) equip.armor = equipCard;
        break;
      case 'horse':
        if (!equip.horse) equip.horse = equipCard;
        break;
      case 'treasure':
        if (!equip.treasure) equip.treasure = equipCard;
        break;
    }
    game.log.push(`${player.name} 装备了【${card.name}】`);
  }
  
  // 弃牌堆
  room.discardPile.push(card);
}

// 计算距离
function getDistance(from: Player, to: Player): number {
  let distance = 1;
  
  if (from.equipCards.horse) distance += 1;
  if (to.equipCards.horse) distance += 1;
  
  if (from.general?.skills.some(s => s.name === '辽阔' || s.name === '出众')) {
    distance -= 1;
  }
  if (to.general?.skills.some(s => s.name === '子涵')) {
    distance += 1;
  }
  
  return Math.max(1, distance);
}

// 结束回合
function endTurn(game: Game): void {
  const room = game.room;
  
  // 清除状态
  const player = room.players[room.turnPlayerIndex];
  player.status.cannotUseJiming = false;
  player.status.cannotTargetPlayer = undefined;
  
  // 下一个玩家
  let nextIdx = (room.turnPlayerIndex + 1) % room.players.length;
  
  // 跳过死亡玩家
  let attempts = 0;
  while (!room.players[nextIdx].status.alive && attempts < room.players.length) {
    nextIdx = (nextIdx + 1) % room.players.length;
    attempts++;
  }
  
  room.turnPlayerIndex = nextIdx;
  
  // 检查胜利
  const alivePlayers = room.players.filter(p => p.status.alive);
  if (alivePlayers.length <= 1) {
    room.status = 'finished';
    if (alivePlayers.length === 1) {
      alert(`游戏结束！${alivePlayers[0].name} 获胜！`);
    }
  }
}
