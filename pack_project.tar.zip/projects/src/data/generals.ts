import { General, Skill, Card, Game } from '../types';

// 武将数据
export const generals: General[] = [
  {
    id: 'zhaoshi',
    name: '诈尸',
    title: '神秘存在',
    hp: 5,
    gender: 'male',
    skills: [
      {
        name: '回炉',
        description: '限定技，当你进入濒死状态时，你可以恢复两点体力，然后摸三张牌',
        canActivate: (game, player) => player.hp <= 0,
        activate: (game, player) => {
          player.hp = Math.min(player.hp + 2, player.maxHp);
          drawCards(game, player, 3);
          game.log.push(`${player.name} 发动了【回炉】，恢复了2点体力并摸3张牌`);
        }
      },
      {
        name: '突袭',
        description: '出牌阶段限一次，你可以弃置一张手牌，令一名角色展示其全部手牌，你获得所有与弃置牌同花色的手牌',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedTuxi,
        activate: (game, player, params: { target: any, card: any }) => {
          if (!params.card || !params.target) return;
          removeHandCard(player, params.card.id);
          const sameSuit = params.target.handCards.filter(c => c.suit === params.card.suit);
          sameSuit.forEach(c => {
            player.handCards.push(c);
            removeHandCard(params.target, c.id);
          });
          player.status.usedTuxi = true;
          game.log.push(`${player.name} 发动了【突袭】，获得了${sameSuit.length}张同花色牌`);
        }
      },
      {
        name: '不灭',
        description: '当你死亡时，你选择一名其他角色，直到其下个回合开始，其不能使用或打出手牌',
        canActivate: (game, player) => player.status.justDied === true,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          params.target.status.cannotUseCards = true;
          game.log.push(`${player.name} 发动了【不灭】，${params.target.name} 不能使用或打出手牌`);
        }
      }
    ]
  },
  {
    id: 'jinlibo',
    name: '金子博',
    title: '子博姐姐',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '买通',
        description: '摸牌阶段，你可以多摸一张牌，但本回合你不能使用"记名"直至你回合结束',
        canActivate: (game, player) => game.phase === 'draw',
        activate: (game, player) => {
          drawCards(game, player, 2);
          player.status.cannotUseJiming = true;
          game.log.push(`${player.name} 发动了【买通】，多摸1张牌，本回合不能使用记名`);
        }
      },
      {
        name: '别说话',
        description: '出牌阶段，你可以失去一点体力，摸两张牌',
        canActivate: (game, player) => game.phase === 'play' && player.hp > 1,
        activate: (game, player) => {
          player.hp--;
          drawCards(game, player, 2);
          game.log.push(`${player.name} 发动了【别说话】，失去1点体力，摸2张牌`);
        }
      }
    ]
  },
  {
    id: 'huangjiaming',
    name: '黄嘉铭',
    title: '科学甜菜',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '变异',
        description: '当你受到伤害时，你可以声明一种颜色，然后进行一次判定，如果判定结果与声明颜色相同，伤害来源代替你成为伤害的目标',
        canActivate: (game, player) => player.status.justDamaged === true,
        activate: (game, player, params: { color: 'red' | 'black', source: any }) => {
          const judgeCard = drawCard(game);
          const isMatch = (params.color === 'red' && (judgeCard.suit === '♥' || judgeCard.suit === '♦')) ||
                         (params.color === 'black' && (judgeCard.suit === '♣' || judgeCard.suit === '♠'));
          if (isMatch && params.source) {
            player.status.justDamaged = false;
            params.source.status.justDamaged = true;
            game.log.push(`${player.name} 发动【变异】成功，伤害转移给${params.source.name}`);
          } else {
            game.log.push(`${player.name} 发动【变异】失败`);
          }
        }
      },
      {
        name: '数学',
        description: '你可以将红色牌当满分试卷使用',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'sunyifan',
    name: '孙一凡',
    title: '英语课代表',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '先知',
        description: '出牌阶段限一次，你可以失去一点体力，然后与一名其他角色交换手牌',
        canActivate: (game, player) => game.phase === 'play' && player.hp > 1 && !player.status.usedXianzhi,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          player.hp--;
          const temp = [...player.handCards];
          player.handCards = [...params.target.handCards];
          params.target.handCards = temp;
          player.status.usedXianzhi = true;
          game.log.push(`${player.name} 发动了【先知】，与${params.target.name}交换了手牌`);
        }
      }
    ]
  },
  {
    id: 'songhaoyu',
    name: '宋浩宇',
    title: '辽阔',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '辽阔',
        description: '你计算其他角色的距离始终-1',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      },
      {
        name: '挑衅',
        description: '出牌阶段限一次，你选择一名其他角色，由其开始，轮流打出记名，首先不出记名的一方受到对方造成的一点伤害',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedTiaoxin,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          player.status.usedTiaoxin = true;
          game.log.push(`${player.name} 发动了【挑衅】，与${params.target.name}进行记名对决`);
        }
      }
    ]
  },
  {
    id: 'zhaitianyou',
    name: '翟天佑',
    title: '幸运努力者',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '幸运',
        description: '当一张判定牌生效前，你可以重新进行一次判定，每牌限一次',
        canActivate: (game, player) => player.status.pendingJudge && !player.status.usedLucky,
        activate: (game, player) => {
          player.status.usedLucky = true;
          game.log.push(`${player.name} 发动了【幸运】，重新判定`);
        }
      }
    ]
  },
  {
    id: 'tanqinze',
    name: '谭钦泽',
    title: '致死负伤',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '滋润',
        description: '出牌阶段限一次，你可以令一名其他角色交给你一张牌，然后回复1点体力',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedZhirun,
        activate: (game, player, params: { target: any }) => {
          if (!params.target || params.target.handCards.length === 0) return;
          const card = params.target.handCards[Math.floor(Math.random() * params.target.handCards.length)];
          removeHandCard(params.target, card.id);
          player.handCards.push(card);
          player.hp = Math.min(player.hp + 1, player.maxHp);
          player.status.usedZhirun = true;
          game.log.push(`${player.name} 发动了【滋润】，从${params.target.name}获得1张牌并回复1点体力`);
        }
      }
    ]
  },
  {
    id: 'zhangshuya',
    name: '张淑雅',
    title: '文静小淑女',
    hp: 4,
    gender: 'female',
    skills: [
      {
        name: '文静',
        description: '锁定技，所有锦囊牌对你无效',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'zhangxunkai',
    name: '张巽凯',
    title: '迅捷如风',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '迅捷',
        description: '摸牌阶段回合开始时，你可以少摸X张牌，若如此做，你视为对一名其他角色使用X张无次数距离限制的记名。其不可以使用广播响应',
        canActivate: (game, player) => game.phase === 'draw',
        activate: (game, player, params: { x: number, target: any }) => {
          if (!params.target || params.x < 1) return;
          player.status.pendingJiming = { count: params.x, target: params.target };
          game.log.push(`${player.name} 发动了【迅捷】，对${params.target.name}使用${params.x}张记名`);
        }
      }
    ]
  },
  {
    id: 'maximing',
    name: '马曦茗',
    title: '神秘学子',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '反伤',
        description: '当你受到伤害时，若你没有广播，你防止此伤害，改为减少一点体力上限',
        canActivate: (game, player) => player.status.justDamaged === true && player.handCards.length === 0,
        activate: (game, player) => {
          player.maxHp--;
          player.hp = Math.min(player.hp, player.maxHp);
          player.status.justDamaged = false;
          game.log.push(`${player.name} 发动了【反伤】，防止伤害但减少1点体力上限`);
        }
      },
      {
        name: '愤怒',
        description: '你可以将红色牌当记名使用或打出',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'yuyaoxi',
    name: '于耀茜',
    title: '黑马',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '醒脑',
        description: '出牌阶段限一次，你可以令一名角色下一次摸牌阶段开始时多摸一张牌',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedXingnao,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          params.target.status.extraDraw = (params.target.status.extraDraw || 0) + 1;
          player.status.usedXingnao = true;
          game.log.push(`${player.name} 发动了【醒脑】，${params.target.name}下次摸牌多摸1张`);
        }
      }
    ]
  },
  {
    id: 'liuzhiqi',
    name: '刘之畦',
    title: '人设保持者',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '耕耘',
        description: '结束阶段限一次，你可以弃置一张牌，然后摸两张牌',
        canActivate: (game, player) => game.phase === 'end' && !player.status.usedGengyun,
        activate: (game, player, params: { card: any }) => {
          if (!params.card || player.handCards.length === 0) return;
          removeHandCard(player, params.card.id);
          drawCards(game, player, 2);
          player.status.usedGengyun = true;
          game.log.push(`${player.name} 发动了【耕耘】，弃1张牌摸2张牌`);
        }
      }
    ]
  },
  {
    id: 'yangkaibo',
    name: '杨凯博',
    title: '胖胖嘟嘟小勇士',
    hp: 6,
    gender: 'male',
    skills: [
      {
        name: '胜负',
        description: '出牌阶段限一次，你可以与其他角色拼点，若你赢，你对其造成1点伤害，若你没赢，则你的下一个回合开始时，你跳过之',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedShengfu,
        activate: (game, player, params: { target: any }) => {
          if (!params.target || player.handCards.length === 0 || params.target.handCards.length === 0) return;
          const pCard = player.handCards[0];
          const tCard = params.target.handCards[0];
          const pPoint = pCard.point;
          const tPoint = tCard.point;
          if (pPoint > tPoint) {
            damage(game, player, params.target, 1);
          } else {
            player.status.skipNextTurn = true;
          }
          player.status.usedShengfu = true;
          game.log.push(`${player.name} 与 ${params.target.name} 拼点`);
        }
      }
    ]
  },
  {
    id: 'diaozihan',
    name: '刁子涵',
    title: '古怪小精灵',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '古怪',
        description: '当你成为"记名"的目标时，你可以弃置攻击者一张牌',
        canActivate: (game, player) => player.status.justBeTargeted === true,
        activate: (game, player, params: { attacker: any }) => {
          if (!params.attacker || params.attacker.handCards.length === 0) return;
          const card = params.attacker.handCards[Math.floor(Math.random() * params.attacker.handCards.length)];
          removeHandCard(params.attacker, card.id);
          game.discardPile.push(card);
          game.log.push(`${player.name} 发动【古怪】，弃置${params.attacker.name}1张牌`);
        }
      },
      {
        name: '子涵',
        description: '锁定技，你计算与其他角色的距离始终+1',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'cuiqijun',
    name: '崔崎骏',
    title: '死亡',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '转学',
        description: '当你受到一点伤害时，你可以弃置一张牌，然后转移此伤害',
        canActivate: (game, player) => player.status.justDamaged === true,
        activate: (game, player, params: { target: any, card: any }) => {
          if (!params.card || !params.target) return;
          removeHandCard(player, params.card.id);
          game.discardPile.push(params.card);
          player.status.justDamaged = false;
          params.target.status.justDamaged = true;
          game.log.push(`${player.name} 发动【转学】，将伤害转移给${params.target.name}`);
        }
      }
    ]
  },
  {
    id: 'lymuruo',
    name: '吕穆若',
    title: '寡言小沉稳',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '慷慨',
        description: '出牌阶段，你可以将一张牌交给一名角色，然后你回复一点体力',
        canActivate: (game, player) => game.phase === 'play' && player.handCards.length > 0,
        activate: (game, player, params: { target: any, card: any }) => {
          if (!params.card || !params.target) return;
          removeHandCard(player, params.card.id);
          params.target.handCards.push(params.card);
          player.hp = Math.min(player.hp + 1, player.maxHp);
          game.log.push(`${player.name} 发动了【慷慨】，交给${params.target.name}1张牌并回复1点体力`);
        }
      },
      {
        name: '体弱',
        description: '你可以将黑色牌当满分试卷使用',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'congzitong',
    name: '丛梓童',
    title: '纯真小童心',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '纯真',
        description: '当你失去最后一张手牌时，你可以摸两张牌',
        canActivate: (game, player) => player.status.justLostLastCard === true,
        activate: (game, player) => {
          drawCards(game, player, 2);
          player.status.justLostLastCard = false;
          game.log.push(`${player.name} 发动了【纯真】，摸2张牌`);
        }
      },
      {
        name: '谦虚',
        description: '锁定技，当任何锦囊牌对你造成伤害后，防止之',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'xianziyi',
    name: '贤梓轶',
    title: '出众作家',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '出众',
        description: '当你计算与其他角色的距离时，始终-1',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      },
      {
        name: '不良',
        description: '锁定技，当你对异性使用牌时，其不可以使用或打出手牌，直至此牌结算结束',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'wangyining',
    name: '王艺凝',
    title: '创想小艺术家',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '创想',
        description: '当你使用锦囊牌时，你可以摸一张牌',
        canActivate: (game, player) => player.status.justUsedTrick === true,
        activate: (game, player) => {
          drawCards(game, player, 1);
          player.status.justUsedTrick = false;
          game.log.push(`${player.name} 发动了【创想】，摸1张牌`);
        }
      },
      {
        name: '音乐',
        description: '锁定技，你使用锦囊牌无距离限制',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'congzhixuan',
    name: '丛芷萱',
    title: '大虫',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '解忧',
        description: '出牌阶段限一次，你可以弃置所有手牌，然后摸等量的牌',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedJieyou && player.handCards.length > 0,
        activate: (game, player) => {
          const count = player.handCards.length;
          player.handCards.forEach(c => game.discardPile.push(c));
          player.handCards = [];
          drawCards(game, player, count);
          player.status.usedJieyou = true;
          game.log.push(`${player.name} 发动了【解忧】`);
        }
      },
      {
        name: '蛋糕',
        description: '当你在回合外获得牌时，交给你牌的角色可以摸一张牌',
        canActivate: (game, player) => player.status.justReceivedCard === true,
        activate: (game, player, params: { from: any }) => {
          if (params.from) {
            drawCards(game, params.from, 1);
          }
          player.status.justReceivedCard = false;
        }
      }
    ]
  },
  {
    id: 'zhaobangjie',
    name: '赵邦杰',
    title: '上任班长（死班长）',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '旧权',
        description: '其他角色使用"记名"造成伤害时后，你可弃其1张牌，令此记名无效',
        canActivate: (game, player) => player.status.canUseJiuquan === true,
        activate: (game, player, params: { attacker: any }) => {
          if (!params.attacker || params.attacker.handCards.length === 0) return;
          const card = params.attacker.handCards[Math.floor(Math.random() * params.attacker.handCards.length)];
          removeHandCard(params.attacker, card.id);
          game.discardPile.push(card);
          params.attacker.status.lastJimingInvalid = true;
          game.log.push(`${player.name} 发动了【旧权`);
        }
      },
      {
        name: '老班威',
        description: '如果攻击学习币比你少的人，伤害+1',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'hanxueying',
    name: '韩雪莹',
    title: '冰雪小晶莹',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '寒澈',
        description: '当你使用"广播"抵消"记名"的效果后，你可以对攻击者造成1点伤害',
        canActivate: (game, player) => player.status.justUsedGuangbo === true,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          damage(game, player, params.target, 1);
          player.status.justUsedGuangbo = false;
          game.log.push(`${player.name} 发动了【寒澈】，对${params.target.name}造成1点伤害`);
        }
      }
    ]
  },
  {
    id: 'luoyi',
    name: '罗祎',
    title: '老师小能手',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '举报',
        description: '锁定技，当你使用"记名"时，你可以令目标角色本回合不能使用"广播"；若目标血量大于或等于你，此伤害+1',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'xiaoyihan',
    name: '肖奕含',
    title: '艺术家',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '创作',
        description: '当你受到伤害时，你可以弃置3张牌，防止之，然后摸两张牌',
        canActivate: (game, player) => player.status.justDamaged === true && player.handCards.length >= 3,
        activate: (game, player) => {
          for (let i = 0; i < 3; i++) {
            if (player.handCards.length > 0) {
              const card = player.handCards.pop()!;
              game.discardPile.push(card);
            }
          }
          drawCards(game, player, 2);
          player.status.justDamaged = false;
          game.log.push(`${player.name} 发动了【创作】`);
        }
      },
      {
        name: '英姿',
        description: '锁定技，你不能成为任何异性角色使用的黑色牌的目标',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'yaohongyu',
    name: '姚泓宇',
    title: '神笔马良',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '妙笔',
        description: '出牌阶段限一次，你可以将一张黑色手牌当任意一张基本牌使用',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedMiaobi,
        activate: (game, player, params: { card: any, targetCard: string }) => {
          if (!params.card) return;
          removeHandCard(player, params.card.id);
          player.status.usedMiaobi = true;
          game.log.push(`${player.name} 发动了【妙笔】`);
        }
      },
      {
        name: '生花',
        description: '当你于回合外使用或打出牌时，你可以摸一张牌',
        canActivate: (game, player) => player.status.usedCardOutsideTurn === true,
        activate: (game, player) => {
          drawCards(game, player, 1);
          player.status.usedCardOutsideTurn = false;
          game.log.push(`${player.name} 发动了【生花】`);
        }
      }
    ]
  },
  {
    id: 'shaoxinran',
    name: '邵欣然',
    title: '欣然小喜乐',
    hp: 4,
    gender: 'female',
    skills: [
      {
        name: '喜颜',
        description: '当你回复一点体力时，你可以令一名其他角色摸一张牌',
        canActivate: (game, player) => player.status.justRecoveredHp === true,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          drawCards(game, params.target, 1);
          player.status.justRecoveredHp = false;
          game.log.push(`${player.name} 发动了【喜颜】，${params.target.name}摸1张牌`);
        }
      }
    ]
  },
  {
    id: 'fengxiaodi',
    name: '冯筱迪',
    title: '外八战神',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '外八',
        description: '出牌阶段限一次，你可以弃置全部手牌，然后指定一名角色，直至该角色下一个回合开始时，其受到的伤害+1',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedWaiba,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          player.handCards.forEach(c => game.discardPile.push(c));
          player.handCards = [];
          params.target.status.damagePlus = (params.target.status.damagePlus || 0) + 1;
          player.status.usedWaiba = true;
          game.log.push(`${player.name} 发动了【外八】，${params.target.name}受到伤害+1`);
        }
      }
    ]
  },
  {
    id: 'xiong yuwei',
    name: '熊羽唯',
    title: '霸气小王者',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '霸气',
        description: '锁定技，当你体力值为1时，你造成的伤害均+1',
        canActivate: (game, player) => player.hp === 1,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'yuanmingwei',
    name: '袁明伟',
    title: '公正小君子',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '正大',
        description: '当你使用"记名"时，若对方或你一方没有手牌，此"记名"造成的伤害+1',
        canActivate: (game, player) => player.status.usingJiming === true,
        activate: (game, player, params: { target: any }) => {
          if (player.handCards.length === 0 || params.target.handCards.length === 0) {
            params.target.status.extraDamage = (params.target.status.extraDamage || 0) + 1;
          }
        }
      }
    ]
  },
  {
    id: 'zhaohanfei',
    name: '赵翰飞',
    title: '小书生',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '书写',
        description: '你可以将一张"广播"当"记名"，记名当广播使用或打出',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'yangqiaoya',
    name: '杨乔雅',
    title: '优雅小佳人',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '魅力',
        description: '出牌阶段限一次，你可以令一名角色交给你一张牌，然后你交给其一张牌',
        canActivate: (game, player) => game.phase === 'play' && !player.status.usedMeili,
        activate: (game, player, params: { target: any }) => {
          if (!params.target || params.target.handCards.length === 0) return;
          const card1 = params.target.handCards[Math.floor(Math.random() * params.target.handCards.length)];
          removeHandCard(params.target, card1.id);
          player.handCards.push(card1);
          
          if (player.handCards.length > 0) {
            const card2 = player.handCards[Math.floor(Math.random() * player.handCards.length)];
            removeHandCard(player, card2.id);
            params.target.handCards.push(card2);
          }
          player.status.usedMeili = true;
          game.log.push(`${player.name} 发动了【魅力】`);
        }
      },
      {
        name: '滑冰',
        description: '你使用任何牌均无距离限制',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'weitianxi',
    name: '魏天晰',
    title: '洞察小智者',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '洞察',
        description: '当一名角色的准备阶段开始时，你可以观看牌堆顶的2张牌，然后将其以任意顺序放回牌堆顶或牌堆底',
        canActivate: (game, player) => player.status.canUseDongcha === true,
        activate: (game, player, params: { cards: Card[] }) => {
          game.log.push(`${player.name} 发动了【洞察】`);
        }
      }
    ]
  },
  {
    id: 'xujiahui',
    name: '徐佳慧',
    title: '现任班长',
    hp: 4,
    gender: 'female',
    skills: [
      {
        name: '包容',
        description: '当一名角色受到伤害后，你可以弃置一张牌，防止此伤害',
        canActivate: (game, player) => player.status.canUseBaoRong === true,
        activate: (game, player, params: { target: any, card: any }) => {
          if (!params.card) return;
          removeHandCard(player, params.card.id);
          game.discardPile.push(params.card);
          params.target.status.justDamaged = false;
          player.status.canUseBaoRong = false;
          game.log.push(`${player.name} 发动了【包容】`);
        }
      },
      {
        name: '秉公',
        description: '结束阶段限一次，你可以让体力最多的其他角色交给你1牌',
        canActivate: (game, player) => game.phase === 'end' && !player.status.usedBinggong,
        activate: (game, player, params: { target: any }) => {
          if (!params.target || params.target.handCards.length === 0) return;
          const card = params.target.handCards[Math.floor(Math.random() * params.target.handCards.length)];
          removeHandCard(params.target, card.id);
          player.handCards.push(card);
          player.status.usedBinggong = true;
          game.log.push(`${player.name} 发动了【秉公】`);
        }
      }
    ]
  },
  {
    id: 'liruoxi',
    name: '李若曦',
    title: '晨曦小暖阳',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '晨曦',
        description: '摸牌阶段，若你体力值不满，你可以多摸一张牌',
        canActivate: (game, player) => game.phase === 'draw' && player.hp < player.maxHp,
        activate: (game, player) => {
          drawCards(game, player, 1);
          game.log.push(`${player.name} 发动了【晨曦】`);
        }
      }
    ]
  },
  {
    id: 'haoduanduan',
    name: '郝端端',
    title: '守规小标兵',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '守规',
        description: '锁定技，你不会成为延时锦囊牌的目标；你的判定牌始终为红色',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      },
      {
        name: '美颜',
        description: '你可以将任意一张牌当作广播使用或打出',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'lingxiangqian',
    name: '凌象乾',
    title: '田径面瘫',
    hp: 3,
    gender: 'male',
    skills: [
      {
        name: '高冷',
        description: '锁定技，你回合第一张"记名"无距离限制，且不可被广播响应',
        canActivate: (game, player) => player.status.firstJimingInTurn === true,
        activate: (game, player) => {}
      },
      {
        name: '速度',
        description: '当你受到伤害后，可看牌堆顶3张牌，任意放回牌堆顶或牌堆底',
        canActivate: (game, player) => player.status.justDamaged === true,
        activate: (game, player) => {
          player.status.justDamaged = false;
          game.log.push(`${player.name} 发动了【速度】`);
        }
      }
    ]
  },
  {
    id: 'lishiyu',
    name: '李诗雨',
    title: '道法课代表',
    hp: 4,
    gender: 'female',
    skills: [
      {
        name: '诗意',
        description: '摸牌阶段结束时，你进行一次判定，若判定结果点数不为K，则你对你选择的一名角色造成一点伤害；若为K，则你受到一点无来源伤害',
        canActivate: (game, player) => game.phase === 'draw',
        activate: (game, player, params: { target: any }) => {
          const judgeCard = drawCard(game);
          if (judgeCard.point !== 13) {
            damage(game, player, params.target, 1);
          } else {
            player.hp--;
            if (player.hp <= 0) {
              player.status.justDied = true;
            }
          }
          game.log.push(`${player.name} 发动了【诗意】`);
        }
      },
      {
        name: '守法',
        description: '当你受到一点伤害后，你可以令一名角色摸牌至体力上限',
        canActivate: (game, player) => player.status.justDamaged === true,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          const need = params.target.maxHp - params.target.handCards.length;
          if (need > 0) {
            drawCards(game, params.target, need);
          }
          player.status.justDamaged = false;
          game.log.push(`${player.name} 发动了【守法】`);
        }
      }
    ]
  },
  {
    id: 'hanxinrui',
    name: '韩欣蕊',
    title: '绽放小花朵',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '绽放',
        description: '你可以将两张手牌当一张"记名"使用，此"记名"造成的伤害+1',
        canActivate: (game, player) => player.handCards.length >= 2,
        activate: (game, player) => {
          game.log.push(`${player.name} 发动了【绽放】`);
        }
      }
    ]
  },
  {
    id: 'dongyixin',
    name: '董轶鑫',
    title: '聚金小能手',
    hp: 5,
    gender: 'male',
    skills: [
      {
        name: '聚金',
        description: '锁定技，摸牌阶段，你少摸一张牌',
        canActivate: (game, player) => game.phase === 'draw',
        activate: (game, player) => {
          game.log.push(`${player.name} 发动了【聚金】`);
        }
      }
    ]
  },
  {
    id: 'zhangxinyang',
    name: '张歆杨',
    title: '向荣暖阳',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '志阳',
        description: '锁定技，你不可以成为记名的目标',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  },
  {
    id: 'zhuxingrui',
    name: '朱星睿',
    title: '小智者',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '星点',
        description: '当你使用"记名"时，你可以进行一次判定，若为红色，此"记名"造成的伤害+1',
        canActivate: (game, player) => player.status.usingJiming === true,
        activate: (game, player) => {
          const judgeCard = drawCard(game);
          const isRed = judgeCard.suit === '♥' || judgeCard.suit === '♦';
          if (isRed) {
            player.status.extraJimingDamage = (player.status.extraJimingDamage || 0) + 1;
          }
          game.log.push(`${player.name} 发动了【星点】`);
        }
      }
    ]
  },
  {
    id: 'xieyuxin',
    name: '解雨欣',
    title: '书虫',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '大爱',
        description: '当一名角色处于濒死状态时，你可以弃置一张基本牌，令其回复1点体力',
        canActivate: (game, player) => player.status.canUseDaai === true,
        activate: (game, player, params: { target: any, card: any }) => {
          if (!params.card || !params.target) return;
          removeHandCard(player, params.card.id);
          game.discardPile.push(params.card);
          params.target.hp = Math.min(params.target.hp + 1, params.target.maxHp);
          player.status.canUseDaai = false;
          game.log.push(`${player.name} 发动了【大爱】`);
        }
      },
      {
        name: '雨欣',
        description: '若你没有相应牌，你可以令一名异性角色回复一点体力并摸一张牌',
        canActivate: (game, player) => player.status.canUseYuxin === true,
        activate: (game, player, params: { target: any }) => {
          if (!params.target) return;
          params.target.hp = Math.min(params.target.hp + 1, params.target.maxHp);
          drawCards(game, params.target, 1);
          player.status.canUseYuxin = false;
          game.log.push(`${player.name} 发动了【雨欣】`);
        }
      }
    ]
  },
  {
    id: 'xialingyu',
    name: '夏聆语',
    title: '善听小读者',
    hp: 3,
    gender: 'female',
    skills: [
      {
        name: '善听',
        description: '当其他角色使用锦囊牌时，你可以摸一张牌',
        canActivate: (game, player) => player.status.canUseShanting === true,
        activate: (game, player) => {
          drawCards(game, player, 1);
          player.status.canUseShanting = false;
          game.log.push(`${player.name} 发动了【善听】`);
        }
      }
    ]
  },
  {
    id: 'liuzhexuan',
    name: '刘哲轩',
    title: '辩证思想家',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '辩证',
        description: '你可以将两张"记名"当一张"广播"使用；也可以将两张"广播"当一张"记名"使用',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      },
      {
        name: '方圆',
        description: '摸牌阶段，你可以多摸一张牌，你的手牌上限等于你的体力上限',
        canActivate: (game, player) => game.phase === 'draw',
        activate: (game, player) => {
          drawCards(game, player, 1);
          game.log.push(`${player.name} 发动了【方圆】`);
        }
      }
    ]
  },
  {
    id: 'zhanghaonan',
    name: '张浩楠',
    title: '坚韧勇士',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '坚韧',
        description: '限定技，锁定技，当你受到伤害时，若此伤害会使你进入濒死状态，防止此伤害，然后将体力回复至体力上限，并摸三张牌',
        canActivate: (game, player) => player.status.justDamaged === true && player.hp <= 1 && !player.status.usedJianren,
        activate: (game, player) => {
          player.status.justDamaged = false;
          player.hp = player.maxHp;
          drawCards(game, player, 3);
          player.status.usedJianren = true;
          game.log.push(`${player.name} 发动了【坚韧】`);
        }
      }
    ]
  },
  {
    id: 'zhangzixuan',
    name: '张子轩',
    'title': '飘逸少年',
    hp: 4,
    gender: 'male',
    skills: [
      {
        name: '飘逸',
        description: '你可以将一张锦囊牌当"满分试卷"使用或打出',
        canActivate: (game, player) => true,
        activate: (game, player) => {}
      }
    ]
  }
];

// 辅助函数
function drawCard(game: any): any {
  if (game.room.deck.length === 0) {
    shuffleDiscardToDeck(game);
  }
  return game.room.deck.pop();
}

function drawCards(game: any, player: any, count: number): void {
  for (let i = 0; i < count; i++) {
    if (game.room.deck.length === 0) {
      shuffleDiscardToDeck(game);
    }
    if (game.room.deck.length > 0) {
      player.handCards.push(game.room.deck.pop());
    }
  }
}

function shuffleDiscardToDeck(game: any): void {
  if (game.discardPile.length > 0) {
    game.room.deck = [...game.discardPile].sort(() => Math.random() - 0.5);
    game.discardPile = [];
  }
}

function removeHandCard(player: any, cardId: string): void {
  const index = player.handCards.findIndex((c: any) => c.id === cardId);
  if (index !== -1) {
    player.handCards.splice(index, 1);
  }
}

function damage(game: any, source: any, target: any, amount: number): void {
  target.hp -= amount;
  if (target.hp <= 0) {
    target.status.justDied = true;
  }
}

export function getGeneralById(id: string): General | undefined {
  return generals.find(g => g.id === id);
}

export function getRandomGenerals(count: number): General[] {
  const shuffled = [...generals].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}
