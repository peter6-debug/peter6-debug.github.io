import { Card, CardType, EquipCard, EquipType, CardSuit, CardColor } from '../types';

// 创建一副牌
const suits: CardSuit[] = ['♥', '♦', '♣', '♠'];
const points = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];

function createCard(id: string, name: string, type: CardType, suit: CardSuit, point: number, description: string): Card {
  const color: CardColor = (suit === '♥' || suit === '♦') ? 'red' : 'black';
  return { id, name, type, suit, point, color, description };
}

// 基本牌
const basicCards: Card[] = [
  // 记名 (普通杀)
  ...suits.flatMap((suit, suitIdx) => 
    points.map((point, idx) => createCard(
      `jiming_${suitIdx}_${idx}`,
      '记名',
      'basic',
      suit,
      point,
      '对距离1的角色造成1点学习币伤害'
    ))
  ),
  // 严重记名 (雷杀)
  ...suits.flatMap((suit, suitIdx) => 
    [11, 12, 13].map((point, idx) => createCard(
      `yanzhongjiming_${suitIdx}_${idx}`,
      '严重记名',
      'basic',
      suit,
      point,
      '雷属性记名，对目标造成2点学习币伤害'
    ))
  ),
  // 警告记名 (火杀)
  ...suits.flatMap((suit, suitIdx) => 
    [10, 11, 12].map((point, idx) => createCard(
      `jinggaojiming_${suitIdx}_${idx}`,
      '警告记名',
      'basic',
      suit,
      point,
      '火属性记名，对目标造成2点学习币伤害，若目标有"手工铠甲"，伤害额外+1'
    ))
  ),
  // 广播做好事记录 (闪)
  ...suits.flatMap((suit, suitIdx) => 
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((point, idx) => createCard(
      `guangbo_${suitIdx}_${idx}`,
      '广播做好事记录',
      'basic',
      suit,
      point,
      '抵消一次"记名"（无论普通还是严重记名）'
    ))
  ),
  // 小红花 (桃)
  ...suits.flatMap((suit, suitIdx) => 
    [1, 2, 3, 4, 5, 6].map((point, idx) => createCard(
      `xiaohonghua_${suitIdx}_${idx}`,
      '小红花',
      'basic',
      suit,
      point,
      '回复1点学习币；若队友学习币为0，可用来救队友'
    ))
  ),
  // 满分试卷 (无中生有)
  ...suits.flatMap((suit, suitIdx) => 
    [1, 2, 3, 4, 5, 6, 7, 8].map((point, idx) => createCard(
      `manfenshijuan_${suitIdx}_${idx}`,
      '满分试卷',
      'basic',
      suit,
      point,
      '本回合下一张"记名"伤害+1；自身学习币为0时，可自救'
    ))
  )
];

// 锦囊牌
const trickCards: Card[] = [
  // 班干部指令 (兵粮寸断)
  createCard('banbujiling', '班干部指令', 'trick', '♣', 1, '指定一名同学，本回合不能使用任何"记名"'),
  createCard('banbujiling2', '班干部指令', 'trick', '♣', 2, '指定一名同学，本回合不能使用任何"记名"'),
  createCard('banbujiling3', '班干部指令', 'trick', '♣', 3, '指定一名同学，本回合不能使用任何"记名"'),
  
  // 调开老师 (拆迁)
  createCard('diaokailaoshi', '调开老师', 'trick', '♥', 1, '本回合，所有其他同学都不能对你使用"记名"'),
  createCard('diaokailaoshi2', '调开老师', 'trick', '♥', 2, '本回合，所有其他同学都不能对你使用"记名"'),
  
  // 没收小玩具 (过河拆桥)
  createCard('moushouwanju', '没收小玩具', 'trick', '♦', 1, '选择一名同学，弃置他手里1张牌'),
  createCard('moushouwanju2', '没收小玩具', 'trick', '♦', 2, '选择一名同学，弃置他手里1张牌'),
  createCard('moushouwanju3', '没收小玩具', 'trick', '♦', 3, '选择一名同学，弃置他手里1张牌'),
  createCard('moushouwanju4', '没收小玩具', 'trick', '♣', 4, '选择一名同学，弃置他手里1张牌'),
  
  // 点燃小纸条 (火攻)
  createCard('dianranxz', '点燃小纸条', 'trick', '♠', 1, '让一名同学展示手里1张牌，若红色，造成1点火属性伤害'),
  createCard('dianranxz2', '点燃小纸条', 'trick', '♠', 2, '让一名同学展示手里1张牌，若红色，造成1点火属性伤害'),
  createCard('dianranxz3', '点燃小纸条', 'trick', '♠', 3, '让一名同学展示手里1张牌，若红色，造成1点火属性伤害'),
  
  // 连环小恶作剧 (铁索连环)
  createCard('lianhuanxz', '连环小恶作剧', 'trick', '♣', 1, '对所有处于"连环扣"状态的同学，各造成1点火属性伤害'),
  createCard('lianhuanxz2', '连环小恶作剧', 'trick', '♣', 2, '对所有处于"连环扣"状态的同学，各造成1点火属性伤害'),
  
  // 借文具"报仇" (借刀杀人)
  createCard('jiewenju', '借文具"报仇"', 'trick', '♥', 1, '向一名有装备牌的同学借1件装备，然后可以用这件装备攻击'),
  createCard('jiewenju2', '借文具"报仇"', 'trick', '♥', 2, '向一名有装备牌的同学借1件装备，然后可以用这件装备攻击'),
  
  // 吵架对决 (拼点)
  createCard('chaojuedj', '吵架对决', 'trick', '♠', 1, '和一名同学轮流打出"记名"，谁先不出，谁就失去1点学习币'),
  createCard('chaojuedj2', '吵架对决', 'trick', '♠', 2, '和一名同学轮流打出"记名"，谁先不出，谁就失去1点学习币'),
  
  // 小组分享会 (五谷丰登)
  createCard('xiaozufenxiang', '小组分享会', 'trick', '♥', 1, '你和所有队友，各恢复1点学习币，再各摸1张牌'),
  createCard('xiaozufenxiang2', '小组分享会', 'trick', '♥', 2, '你和所有队友，各恢复1点学习币，再各摸1张牌'),
  
  // 团结一心 (义结金兰)
  createCard('tuanjieyixin', '团结一心', 'trick', '♦', 1, '本回合，你和所有队友打出的"记名"，伤害都+1'),
  createCard('tuanjieyixin2', '团结一心', 'trick', '♦', 2, '本回合，你和所有队友打出的"记名"，伤害都+1'),
  
  // 班主任回班 (万箭齐发)
  createCard('banzhuren', '班主任回班', 'trick', '♥', 1, '除你之外，所有同学都必须打出1张"记名"，谁不出，谁就失去1点学习币'),
  createCard('banzhuren2', '班主任回班', 'trick', '♦', 3, '除你之外，所有同学都必须打出1张"记名"，谁不出，谁就失去1点学习币'),
  
  // 大扫除惩罚 (大扫除)
  createCard('dasaochu', '大扫除惩罚', 'trick', '♣', 1, '1V1模式专用：让对方弃置所有装备牌，或者失去2点学习币'),
  
  // 借东西不还 (顺手牵羊)
  createCard('jiedongxi', '借东西不还', 'trick', '♠', 1, '选择距离1的一名同学，从他手里拿1张牌'),
  createCard('jiedongxi2', '借东西不还', 'trick', '♠', 2, '选择距离1的一名同学，从他手里拿1张牌'),
  createCard('jiedongxi3', '借东西不还', 'trick', '♠', 3, '选择距离1的一名同学，从他手里拿1张牌'),
  createCard('jiedongxi4', '借东西不还', 'trick', '♥', 4, '选择距离1的一名同学，从他手里拿1张牌'),
  
  // 全班分享小红花 (桃园结义)
  createCard('quanbanfx', '全班分享小红花', 'trick', '♥', 1, '所有同学（包括你自己），各恢复1点学习币'),
  createCard('quanbanfx2', '全班分享小红花', 'trick', '♥', 2, '所有同学（包括你自己），各恢复1点学习币'),
  
  // 连环扣 (铁索连环)
  createCard('lianhuankou', '连环扣', 'trick', '♣', 1, '选择1-2名同学，将他们"连环"起来'),
  createCard('lianhuankou2', '连环扣', 'trick', '♣', 2, '选择1-2名同学，将他们"连环"起来'),
  
  // 反抗占课 (南蛮入侵)
  createCard('fankangzk', '反抗占课', 'trick', '♠', 1, '除你之外，所有同学都必须打出1张"广播"，谁不出，谁就失去1点学习币'),
  createCard('fankangzk2', '反抗占课', 'trick', '♠', 2, '除你之外，所有同学都必须打出1张"广播"，谁不出，谁就失去1点学习币'),
  
  // 发作业本 (分发)
  createCard('fazuoyeben', '发作业本', 'trick', '♦', 1, '从牌堆摸出和在场同学数量一样多的牌，摊开后，从你开始，每人依次选1张牌拿走'),
  
  // 领导检查 (无懈可击)
  createCard('lingdaojc', '领导检查', 'trick', '♥', 1, '可以抵消任意一张锦囊牌的效果'),
  createCard('lingdaojc2', '领导检查', 'trick', '♦', 2, '可以抵消任意一张锦囊牌的效果'),
  createCard('lingdaojc3', '领导检查', 'trick', '♣', 3, '可以抵消任意一张锦囊牌的效果'),
  createCard('lingdaojc4', '领导检查', 'trick', '♠', 4, '可以抵消任意一张锦囊牌的效果'),
  
  // 意外奖励 (无中生有)
  createCard('yiweijl', '意外奖励', 'trick', '♥', 1, '从牌堆摸2张牌'),
  createCard('yiweijl2', '意外奖励', 'trick', '♦', 2, '从牌堆摸2张牌'),
  createCard('yiweijl3', '意外奖励', 'trick', '♥', 3, '从牌堆摸2张牌'),
  createCard('yiweijl4', '意外奖励', 'trick', '♦', 4, '从牌堆摸2张牌'),
  
  // 请老师发话 (乐不思蜀)
  createCard('qinglaoshifh', '请老师发话', 'trick', '♣', 1, '指定一名同学，本回合不能打出任何牌'),
  
  // 闪电判定 (闪电)
  createCard('shandianpd', '闪电判定', 'trick', '♠', 1, '判定：若为黑桃2-9，判定成功造成3点伤害'),
];

// 装备牌
const equipCards: EquipCard[] = [
  // 武器
  { id: 'wuqi_1', name: '连发铅笔', type: 'equip', suit: '♠', point: 1, color: 'black', description: '出牌阶段可以使用任意张"记名"', equipType: 'weapon' },
  { id: 'wuqi_2', name: '同桌互助尺', type: 'equip', suit: '♥', point: 2, color: 'red', description: '使用"记名"指定异性同学后，可让其弃1张牌，或你摸1张牌', equipType: 'weapon' },
  { id: 'wuqi_3', name: '破障小刀', type: 'equip', suit: '♣', point: 3, color: 'black', description: '使用"记名"时，无视对方的防具效果', equipType: 'weapon' },
  { id: 'wuqi_4', name: '长画笔', type: 'equip', suit: '♦', point: 4, color: 'red', description: '可将两张手牌当作"记名"使用', equipType: 'weapon' },
  { id: 'wuqi_5', name: '结实直尺', type: 'equip', suit: '♠', point: 5, color: 'black', description: '"记名"被对方用"广播"抵消时，可弃2张牌强制命中', equipType: 'weapon' },
  { id: 'wuqi_6', name: '长柄扫帚', type: 'equip', suit: '♥', point: 6, color: 'red', description: '"记名"被抵消时，可继续使用1张"记名"', equipType: 'weapon' },
  { id: 'wuqi_7', name: '四格长尺', type: 'equip', suit: '♣', point: 7, color: 'black', description: '使用最后1张"记名"时，可最多指定3名同学为目标', equipType: 'weapon' },
  { id: 'wuqi_8', name: '远射玩具弓', type: 'equip', suit: '♦', point: 8, color: 'red', description: '"记名"命中后，可弃掉对方1件坐骑', equipType: 'weapon' },
  { id: 'wuqi_9', name: '冷静冰棒刀', type: 'equip', suit: '♠', point: 9, color: 'black', description: '"记名"命中时，可不让对方掉学习币，改为弃其2张牌', equipType: 'weapon' },
  { id: 'wuqi_10', name: '锋利削笔刀', type: 'equip', suit: '♥', point: 10, color: 'red', description: '对方没有手牌时，"记名"伤害+1', equipType: 'weapon' },
  { id: 'wuqi_11', name: '彩色卡通扇', type: 'equip', suit: '♣', point: 11, color: 'black', description: '可将普通"记名"当作"警告记名"使用', equipType: 'weapon' },
  { id: 'wuqi_12', name: '弹射玩具枪', type: 'equip', suit: '♦', point: 12, color: 'red', description: '打出"广播"时，可对距离3以内的同学造成1点伤害', equipType: 'weapon' },
  { id: 'wuqi_13', name: '小组合作剑', type: 'equip', suit: '♠', point: 1, color: 'black', description: '同组所有同学的攻击距离+1', equipType: 'weapon' },
  { id: 'wuqi_14', name: '三叉塑料笔', type: 'equip', suit: '♥', point: 2, color: 'red', description: '"记名"命中1名同学后，可对另1名同学造成1点伤害', equipType: 'weapon' },
  { id: 'wuqi_15', name: '飞行卡通笔', type: 'equip', suit: '♣', point: 3, color: 'black', description: '"记名"命中后，可获得对方1张牌', equipType: 'weapon' },
  { id: 'wuqi_16', name: '精美卡通刀', type: 'equip', suit: '♦', point: 4, color: 'red', description: '"记名"命中后，可从牌堆摸1张牌', equipType: 'weapon' },
  { id: 'wuqi_17', name: '坚固塑料矛', type: 'equip', suit: '♠', point: 5, color: 'black', description: '使用"记名"时，对方不能用"广播"抵消', equipType: 'weapon' },
  { id: 'wuqi_18', name: '恐龙造型长刀', type: 'equip', suit: '♥', point: 6, color: 'red', description: '"记名"伤害+1，若命中手牌≥3张的同学，额外造成1点伤害', equipType: 'weapon' },
  { id: 'wuqi_19', name: '卡通电子琴', type: 'equip', suit: '♣', point: 7, color: 'black', description: '使用"记名"后，可让对方本回合不能使用锦囊牌', equipType: 'weapon' },
  { id: 'wuqi_20', name: '恶魔造型长戟', type: 'equip', suit: '♦', point: 8, color: 'red', description: '"记名"命中后，可让对方弃掉所有手牌', equipType: 'weapon' },
  { id: 'wuqi_21', name: '红色美工刀', type: 'equip', suit: '♠', point: 9, color: 'black', description: '"记名"命中后，可让对方下回合不能摸牌', equipType: 'weapon' },
  { id: 'wuqi_22', name: '双子卡通剑', type: 'equip', suit: '♥', point: 10, color: 'red', description: '使用"记名"指定同组同学相邻的角色时，伤害+1', equipType: 'weapon' },
  { id: 'wuqi_23', name: '太阳造型长弓', type: 'equip', suit: '♣', point: 11, color: 'black', description: '"记名"可指定距离6以内的任意1名同学', equipType: 'weapon' },
  { id: 'wuqi_24', name: '大力卡通斧', type: 'equip', suit: '♦', point: 12, color: 'red', description: '"记名"被抵消时，可弃1张牌，对对方造成1点伤害', equipType: 'weapon' },
  { id: 'wuqi_25', name: '巨型玩具车', type: 'equip', suit: '♠', point: 1, color: 'black', description: '"记名"命中后，可弃掉对方所有装备牌', equipType: 'weapon' },
  { id: 'wuqi_26', name: '超大塑料长尺', type: 'equip', suit: '♥', point: 2, color: 'red', description: '使用"记名"时，可指定2-3名同学为目标', equipType: 'weapon' },
  { id: 'wuqi_27', name: '连发玩具弩', type: 'equip', suit: '♣', point: 3, color: 'black', description: '出牌阶段可使用任意张"记名"，且"记名"伤害+1', equipType: 'weapon' },
  { id: 'wuqi_28', name: '破损塑料戟', type: 'equip', suit: '♦', point: 4, color: 'red', description: '"记名"伤害不变，若对方有防具，可额外弃其1张手牌', equipType: 'weapon' },
  { id: 'wuqi_29', name: '无尖安全剑', type: 'equip', suit: '♠', point: 5, color: 'black', description: '"记名"命中后，可让对方弃1张牌，或自己恢复1点学习币', equipType: 'weapon' },
  { id: 'wuqi_30', name: '长柄玩具枪', type: 'equip', suit: '♥', point: 6, color: 'red', description: '"记名"未命中时，可再使用1张"记名"', equipType: 'weapon' },
  { id: 'wuqi_31', name: '龙形卡通剑', type: 'equip', suit: '♣', point: 7, color: 'black', description: '"记名"伤害+1，无视对方1件坐骑的效果', equipType: 'weapon' },
  { id: 'wuqi_32', name: '复古玩具弩', type: 'equip', suit: '♦', point: 8, color: 'red', description: '"记名"可指定距离4以内的同学', equipType: 'weapon' },
  { id: 'wuqi_33', name: '彩色羽毛扇', type: 'equip', suit: '♠', point: 9, color: 'black', description: '可将普通"记名"当作"严重记名"或"警告记名"使用', equipType: 'weapon' },
  { id: 'wuqi_34', name: '塑料锁链', type: 'equip', suit: '♥', point: 10, color: 'red', description: '使用"记名"时，可同时将目标与另1名同学"连环"', equipType: 'weapon' },
  
  // 防具
  { id: 'fangyu_1', name: '安全小背心', type: 'equip', suit: '♥', point: 1, color: 'red', description: '需要出"广播"时，判定：红桃则视为已出"广播"', equipType: 'armor' },
  { id: 'fangyu_2', name: '纪律盾牌', type: 'equip', suit: '♠', point: 2, color: 'black', description: '黑色"记名"对自己无效', equipType: 'armor' },
  { id: 'fangyu_3', name: '手工纸铠甲', type: 'equip', suit: '♣', point: 3, color: 'black', description: '普通"记名"对自己无效，但火属性"警告记名"伤害+1', equipType: 'armor' },
  { id: 'fangyu_4', name: '软甲头盔', type: 'equip', suit: '♦', point: 4, color: 'red', description: '每次受到的伤害最多为1点', equipType: 'armor' },
  { id: 'fangyu_5', name: '反光卡通甲', type: 'equip', suit: '♥', point: 5, color: 'red', description: '免疫火属性"警告记名"的伤害', equipType: 'armor' },
  { id: 'fangyu_6', name: '学习秘籍', type: 'equip', suit: '♠', point: 6, color: 'black', description: '受到伤害时，可从牌堆摸1张牌', equipType: 'armor' },
  { id: 'fangyu_7', name: '银色塑料甲', type: 'equip', suit: '♣', point: 7, color: 'black', description: '每次受到伤害后，可从牌堆摸1张牌', equipType: 'armor' },
  { id: 'fangyu_8', name: '中式卡通袍', type: 'equip', suit: '♦', point: 8, color: 'red', description: '每次受到伤害时，可让伤害来源弃1张牌', equipType: 'armor' },
  { id: 'fangyu_9', name: '趣味八卦牌', type: 'equip', suit: '♠', point: 9, color: 'black', description: '需要出"广播"时，判定：红色牌则视为已出"广播"，且可摸1张牌', equipType: 'armor' },
  { id: 'fangyu_10', name: '花布小外套', type: 'equip', suit: '♥', point: 10, color: 'red', description: '免疫所有锦囊牌造成的学习币伤害', equipType: 'armor' },
  { id: 'fangyu_11', name: '卡通腰带', type: 'equip', suit: '♣', point: 11, color: 'black', description: '手牌上限+1，且不会被对方弃掉超过1张牌/回合', equipType: 'armor' },
  { id: 'fangyu_12', name: '高级八卦背心', type: 'equip', suit: '♦', point: 12, color: 'red', description: '需要出"广播"时，判定：任意花色均可视为已出"广播"，失败可重判1次', equipType: 'armor' },
  { id: 'fangyu_13', name: '超级纪律盾', type: 'equip', suit: '♠', point: 1, color: 'black', description: '黑色"记名"和黑色锦囊牌对自己均无效', equipType: 'armor' },
  { id: 'fangyu_14', name: '防水纸铠甲', type: 'equip', suit: '♥', point: 2, color: 'red', description: '普通"记名"无效，且免疫雷属性"严重记名"的伤害', equipType: 'armor' },
  { id: 'fangyu_15', name: '狮子造型头盔', type: 'equip', suit: '♣', point: 3, color: 'black', description: '受到伤害时，有一半概率减免1点伤害', equipType: 'armor' },
  { id: 'fangyu_16', name: '黑色小披风', type: 'equip', suit: '♦', point: 4, color: 'red', description: '对方不能指定自己为"记名"或锦囊牌的唯一目标', equipType: 'armor' },
  { id: 'fangyu_17', name: '带刺小外套', type: 'equip', suit: '♠', point: 5, color: 'black', description: '攻击自己的同学，命中后会受到1点学习币伤害', equipType: 'armor' },
  { id: 'fangyu_18', name: '卡通连衣裙', type: 'equip', suit: '♥', point: 6, color: 'red', description: '异性同学对自己使用"记名"时，伤害-1；可弃掉这件防具，抵消1次伤害', equipType: 'armor' },
  { id: 'fangyu_19', name: '黑色反光甲', type: 'equip', suit: '♣', point: 7, color: 'black', description: '免疫所有属性伤害（雷、火），且普通"记名"伤害-1', equipType: 'armor' },
  { id: 'fangyu_20', name: '塑料护心镜', type: 'equip', suit: '♦', point: 8, color: 'red', description: '可抵消1次任意属性伤害（雷、火），抵消后弃掉这件防具', equipType: 'armor' },
  { id: 'fangyu_21', name: '座位所有权证', type: 'equip', suit: '♠', point: 9, color: 'black', description: '手牌上限+2，且不会被对方"借东西不还"拿走手牌', equipType: 'armor' },
  
  // 马
  { id: 'ma_1', name: '快速运动鞋', type: 'equip', suit: '♣', point: 1, color: 'black', description: '其他同学计算与你的距离+1', equipType: 'horse' },
  { id: 'ma_2', name: '轻便运动鞋', type: 'equip', suit: '♦', point: 2, color: 'red', description: '其他同学计算与你的距离+1，且你摸牌阶段多摸1张牌', equipType: 'horse' },
  { id: 'ma_3', name: '防滑运动鞋', type: 'equip', suit: '♠', point: 3, color: 'black', description: '其他同学计算与你的距离+1，受到伤害时可弃掉这匹马，减免1点伤害', equipType: 'horse' },
  { id: 'ma_4', name: '高档运动鞋', type: 'equip', suit: '♥', point: 4, color: 'red', description: '其他同学计算与你的距离+1，且你手牌上限+1', equipType: 'horse' },
  { id: 'ma_5', name: '彩色跑步鞋', type: 'equip', suit: '♣', point: 5, color: 'black', description: '你计算与其他同学的距离-1', equipType: 'horse' },
  { id: 'ma_6', name: '飞快跑步鞋', type: 'equip', suit: '♦', point: 6, color: 'red', description: '你计算与其他同学的距离-1，且"记名"未命中时可再出1张牌', equipType: 'horse' },
  { id: 'ma_7', name: '闪电跑步鞋', type: 'equip', suit: '♠', point: 7, color: 'black', description: '你计算与其他同学的距离-1，且"记名"伤害+1', equipType: 'horse' },
  { id: 'ma_8', name: '疾风跑步鞋', type: 'equip', suit: '♥', point: 8, color: 'red', description: '你计算与其他同学的距离-1，且可无视1件对方的坐骑效果', equipType: 'horse' },
  { id: 'ma_9', name: '金色滑板', type: 'equip', suit: '♣', point: 9, color: 'black', description: '其他同学计算与你的距离+2，且你不会被"连环扣"', equipType: 'horse' },
  { id: 'ma_10', name: '卡通小鹿坐骑', type: 'equip', suit: '♦', point: 10, color: 'red', description: '其他同学计算与你的距离+1，你每次摸牌可多摸1张', equipType: 'horse' },
  { id: 'ma_11', name: '慢速拖鞋', type: 'equip', suit: '♠', point: 11, color: 'black', description: '你和其他同学计算彼此的距离均不变，但你手牌上限-1', equipType: 'horse' },
  { id: 'ma_12', name: '超级卡通校车', type: 'equip', suit: '♥', point: 12, color: 'red', description: '你和同组所有同学，计算距离时均±1', equipType: 'horse' },
  
  // 宝物
  { id: 'baowu_1', name: '卡通书包', type: 'equip', suit: '♣', point: 1, color: 'black', description: '可将多余的手牌放在书包里，回合结束时可摸回这些牌（最多放3张）', equipType: 'treasure' },
  { id: 'baowu_2', name: '班长徽章', type: 'equip', suit: '♦', point: 2, color: 'red', description: '出牌阶段可多使用1张"记名"，且同组同学手牌上限+1', equipType: 'treasure' },
  { id: 'baowu_3', name: '发光玩具球', type: 'equip', suit: '♠', point: 3, color: 'black', description: '手牌上限+1，摸牌阶段可多摸1张牌', equipType: 'treasure' },
  { id: 'baowu_4', name: '卡通皇冠', type: 'equip', suit: '♥', point: 4, color: 'red', description: '每次使用锦囊牌后，可摸1张牌；但受到的伤害+1', equipType: 'treasure' },
  { id: 'baowu_5', name: '班长让位书', type: 'equip', suit: '♣', point: 5, color: 'black', description: '可将自己的"班长徽章"转给同组同学，同时双方各恢复1点学习币', equipType: 'treasure' },
  { id: 'baowu_6', name: '卡通发饰', type: 'equip', suit: '♦', point: 6, color: 'red', description: '女性同学使用时，手牌上限+2；男性同学使用时，"记名"伤害+1', equipType: 'treasure' },
  { id: 'baowu_7', name: '金色卡通头冠', type: 'equip', suit: '♠', point: 7, color: 'black', description: '摸牌阶段多摸1张牌，且不会被对方"没收小玩具"', equipType: 'treasure' },
  { id: 'baowu_8', name: '卡通礼品盒', type: 'equip', suit: '♥', point: 8, color: 'red', description: '可存放1张牌，需要时再拿出来使用（最多存放1张）', equipType: 'treasure' },
  { id: 'baowu_9', name: '特级班长徽章', type: 'equip', suit: '♣', point: 9, color: 'black', description: '出牌阶段可使用任意张"记名"，且同组所有同学"记名"伤害+1', equipType: 'treasure' },
  { id: 'baowu_10', name: '卡通小鸟摆件', type: 'equip', suit: '♦', point: 10, color: 'red', description: '同组同学弃牌时，可选择1张牌交给你', equipType: 'treasure' },
  { id: 'baowu_11', name: '趣味迷宫图', type: 'equip', suit: '♠', point: 11, color: 'black', description: '每次判定前，可更换1张判定牌（改变判定结果）', equipType: 'treasure' },
  { id: 'baowu_12', name: '神秘卡片', type: 'equip', suit: '♥', point: 12, color: 'red', description: '可将1张手牌当作任意1张基本牌使用', equipType: 'treasure' },
  { id: 'baowu_13', name: '卡通小推车', type: 'equip', suit: '♣', point: 13, color: 'black', description: '同组所有同学，回合结束时可各恢复1点学习币', equipType: 'treasure' },
  { id: 'baowu_14', name: '带刺小推车', type: 'equip', suit: '♦', point: 1, color: 'red', description: '对方同学计算与你的距离+1，且攻击你时会受到1点学习币伤害', equipType: 'treasure' },
  { id: 'baowu_15', name: '旋转玩具车', type: 'equip', suit: '♠', point: 2, color: 'black', description: '你计算与其他同学的距离-1，且每次"记名"命中后可摸1张牌', equipType: 'treasure' },
  { id: 'baowu_16', name: '学习小手册', type: 'equip', suit: '♥', point: 3, color: 'red', description: '同组同学使用锦囊牌时，可额外抵消1次对方的"领导检查"', equipType: 'treasure' }
];

// 所有卡牌
export const allCards: Card[] = [...basicCards, ...trickCards, ...equipCards];

// 创建牌堆
export function createDeck(): Card[] {
  const deck = [...allCards];
  // 洗牌
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

// 获取卡牌类型
export function getCardType(card: Card): CardType {
  return card.type;
}

// 是否是装备牌
export function isEquipCard(card: Card): card is EquipCard {
  return card.type === 'equip';
}

// 是否是基本牌
export function isBasicCard(card: Card): boolean {
  return card.type === 'basic';
}

// 是否是锦囊牌
export function isTrickCard(card: Card): boolean {
  return card.type === 'trick';
}

// 是否是杀
export function isJiming(card: Card): boolean {
  return card.name === '记名' || card.name === '严重记名' || card.name === '警告记名';
}

// 是否是闪
export function isGuangbo(card: Card): boolean {
  return card.name === '广播做好事记录';
}

// 是否是桃
export function isXiaohonghua(card: Card): boolean {
  return card.name === '小红花';
}

// 是否是无中生有
export function isManfenshijuan(card: Card): boolean {
  return card.name === '满分试卷';
}
